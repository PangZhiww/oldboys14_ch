addr = ("127.0.0.1",8080)
code = "utf-8"
home_path = r"C:\Users\66349\Desktop\practice\python\oldboy14\day34\server\home"
space = 1024*1024*2
user_info = r"C:\Users\66349\Desktop\practice\python\oldboy14\day34\server\db\userinfo"
pickle_path = r"C:\Users\66349\Desktop\practice\python\oldboy14\day34\server\db\user_pickle"
